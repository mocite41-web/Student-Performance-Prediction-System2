# Student Performance Prediction System

A classroom prototype that estimates whether a student is **at risk of failing the final Mathematics grade**, built with Python, scikit-learn and Streamlit.

> **Responsible use:** This is a classroom demonstration using public, historical data. Predictions are not diagnoses and must not be used as the sole basis for real student decisions.

## Problem
Academic risk is often noticed only after poor results. This prototype explores early identification of students who may need extra academic support, using information that is already available.

## Dataset
[UCI Machine Learning Repository - Student Performance](https://archive.ics.uci.edu/dataset/320/student+performance) (ID 320), Mathematics records. It contains demographic, social and academic attributes of Portuguese secondary-school students, including the period grades G1, G2 and G3.

## Prediction target
| Rule | Label |
|---|---|
| G3 < 10 | `AT RISK` (1) |
| G3 >= 10 | `NOT AT RISK` (0) |

`G3` is the target only and is **never** used as an input feature (this would be target leakage).

## Technologies
Python 3.10+, pandas, scikit-learn (Random Forest), joblib, ucimlrepo, Streamlit.

## Project files
```
student-performance-prediction/
├── train_model.py     # downloads data, preprocesses, trains and evaluates the model
├── app.py             # Streamlit dashboard + CSV prediction upload
├── requirements.txt
└── README.md
```
`train_model.py` generates `student_data.csv`, `student_model.pkl` and `model_metrics.json`.

## Installation and run
```bash
git clone https://github.com/YOUR-USERNAME/student-performance-prediction.git
cd student-performance-prediction
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python train_model.py      # creates student_data.csv, student_model.pkl, model_metrics.json
streamlit run app.py       # opens http://localhost:8501
```
In the app, download the sample input CSV and upload it to see predictions; the results can be downloaded as CSV. If an uploaded file lacks a required column, the app lists the missing columns.

## Model
Pipeline: median imputation + standard scaling (numeric), most-frequent imputation + one-hot encoding (categorical), then a `RandomForestClassifier` (100 trees, `class_weight="balanced"`). 80/20 stratified train/test split, `random_state=42`.

## Evaluation results
Run `python train_model.py` and copy the values for the **At risk** class here:

| Accuracy | Precision | Recall | F1-score |
|---|---|---|---|
| _fill in_ | _fill in_ | _fill in_ | _fill in_ |

Do not interpret accuracy alone. Recall for the At-risk class shows how many truly at-risk students the model catches.

## Limitations
- Trained on one Portuguese secondary-school dataset; it may not generalise to other institutions, curricula or populations.
- Small dataset (a few hundred records), so metrics vary with the split.
- G1 and G2 are strong predictors, so the model flags risk late in the term rather than early.
- Predictions are probabilistic and should prompt a conversation with the student, not an automatic decision.

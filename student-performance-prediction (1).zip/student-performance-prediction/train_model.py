# train_model.py
# Student Performance Prediction System - data retrieval, training, evaluation.
# Run once with:  python train_model.py
import json

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import (accuracy_score, classification_report,
                             f1_score, precision_score, recall_score)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from ucimlrepo import fetch_ucirepo

# ---------------------------------------------------------------------------
# Activity A - Retrieve and inspect the dataset
# ---------------------------------------------------------------------------
# Fetch UCI Student Performance dataset (ID 320)
student = fetch_ucirepo(id=320)

# Combine student features and grade targets (G1, G2, G3)
df = pd.concat([student.data.features, student.data.targets], axis=1)

# Save the records as a CSV file
df.to_csv("student_data.csv", index=False)

print("Rows and columns:", df.shape)
print(df.head())
print(df.dtypes)
print("Missing values per column:")
print(df.isnull().sum())

# The lab specifies the Mathematics file (395 records in the original data).
if df.shape[0] != 395:
    print(f"WARNING: expected 395 Mathematics records, got {df.shape[0]}. "
          "Check with your instructor which UCI file this download contains.")

# ---------------------------------------------------------------------------
# Activity B - Preprocess, train, and evaluate
# ---------------------------------------------------------------------------
# Target: 1 = at risk (G3 < 10); 0 = not at risk
df = df.drop_duplicates()
y = (df["G3"] < 10).astype(int)

# Never use G3 as a predictor (target leakage)
X = df.drop(columns=["G3"])

numeric_cols = X.select_dtypes(include="number").columns.tolist()
categorical_cols = X.select_dtypes(exclude="number").columns.tolist()

numeric_pipe = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler()),
])
categorical_pipe = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("encoder", OneHotEncoder(handle_unknown="ignore")),
])
preprocessor = ColumnTransformer([
    ("numeric", numeric_pipe, numeric_cols),
    ("categorical", categorical_pipe, categorical_cols),
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

model = Pipeline([
    ("preprocessor", preprocessor),
    ("classifier", RandomForestClassifier(
        n_estimators=100,
        random_state=42,
        class_weight="balanced",
    )),
])

model.fit(X_train, y_train)
predictions = model.predict(X_test)

print("Accuracy:", round(accuracy_score(y_test, predictions), 3))
print(classification_report(
    y_test, predictions,
    target_names=["Not at risk", "At risk"],
    zero_division=0,
))

# Metrics for the 'At risk' class (label 1), saved for the report and the app
metrics = {
    "accuracy": round(accuracy_score(y_test, predictions), 3),
    "precision_at_risk": round(precision_score(y_test, predictions, zero_division=0), 3),
    "recall_at_risk": round(recall_score(y_test, predictions, zero_division=0), 3),
    "f1_at_risk": round(f1_score(y_test, predictions, zero_division=0), 3),
    "train_rows": int(len(X_train)),
    "test_rows": int(len(X_test)),
}
with open("model_metrics.json", "w") as f:
    json.dump(metrics, f, indent=2)
print("Metrics:", metrics)

joblib.dump(model, "student_model.pkl")
print("Saved student_model.pkl")
